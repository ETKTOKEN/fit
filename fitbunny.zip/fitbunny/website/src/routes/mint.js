const router = require('express').Router();

/** URL: / */
router.get('/', async (req, res) => {
    
    res.render('mint', {
        page_title: 'Mint',
        config: require('../config/config.json')
    })

})

module.exports = router;