const router = require('express').Router();

/** URL: / */
router.get('/', async (req, res) => {
    
    res.render('index', {
        page_title: 'Home',
        config: require('../config/config.json')
    })

})

module.exports = router;