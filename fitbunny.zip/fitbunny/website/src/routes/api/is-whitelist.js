const router = require('express').Router();

const { ethers } = require('ethers')
var rString = require("randomstring")

const FreeClaimList = require('./free_claim.json')
const Whitelist = require('./whitelist.json')

router.post('/', async (req, res) => { 


    //- Getting the input
    let _wallet = req.body.wallet
    let _claimType = req.body.claim_type ? req.body.claim_type : null


    //- Generating a hash
    if(_claimType == 'free') {

        let _isWhitelist = FreeClaimList.find(x => x.wallet.toLowerCase() === _wallet.toLowerCase())
        return res.json({ status: 200, data: _isWhitelist ? _isWhitelist.allowed : false })
            
    } 
    else if(_claimType == 'whitelist') {

        let _isWhitelist = Whitelist.find(x => x.wallet.toLowerCase() === _wallet.toLowerCase())
        return res.json({ status: 200, data: _isWhitelist ? _isWhitelist.allowed : false })

    } 

    return res.json({ status: 200, data: false })

})

module.exports = router;