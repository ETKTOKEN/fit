const router = require('express').Router();

const { ethers } = require('ethers')
var rString = require("randomstring")

const FreeClaimList = require('./free_claim.json')
const Whitelist = require('./whitelist.json')

router.post('/', async (req, res) => { 


    //- Getting the input
    let _wallet = req.body.wallet
    let _amount = req.body.amount
    let _enabled = req.body.mint_enabled ? req.body.mint_enabled === 'true' : false
    let _claimType = req.body.claim_type ? req.body.claim_type : null

    let _claimCode = null

    //- Generating a hash
    let _hash = null
    try {
        if(_claimType == 'free') {

            let _isWhitelist = FreeClaimList.find(x => x.wallet.toLowerCase() === _wallet.toLowerCase())

            _claimCode = rString.generate({ length: 12, charset: 'alphabetic' })
            _hash = _isWhitelist.allowed
                ? ethers.solidityPackedKeccak256(['address', 'uint8', 'string'], [_wallet, _amount, _claimCode])
                : ethers.solidityPackedKeccak256(['address', 'uint8', 'string'], [_wallet, _amount, 'not_whitelisted'])
        } 
        else if(_claimType == 'whitelist') {

            let _isWhitelist = Whitelist.find(x => x.wallet.toLowerCase() === _wallet.toLowerCase())

            _claimCode = rString.generate({ length: 12, charset: 'alphabetic' })
            _hash = _isWhitelist.allowed
                ? ethers.solidityPackedKeccak256(['address', 'uint8', 'string'], [_wallet, _amount, _claimCode])
                : ethers.solidityPackedKeccak256(['address', 'uint8', 'string'], [_wallet, _amount, 'not_whitelisted'])
        } 
        else {
            _hash = ethers.solidityPackedKeccak256(['address', 'uint256', 'bool'], [_wallet, _amount, _enabled])
        }
    } catch(err) {
        console.log(err)
        return res.json({ status: 500, error: err.message })
    }

    //- 
    try {
        let _signer = new ethers.Wallet(process.env._PRIVATE_KEY)
        let _signature = await _signer.signMessage(ethers.getBytes(_hash))

        //- Testing
        // let _test = await ethers.verifyMessage(_hash, _signature)
        // console.log(`_test: ${_test}`)
        // if(_test !== _signer.address)
        //     console.log(`TEST FAILED!`)
        
        if(_claimType == 'free' || _claimType == 'whitelist') {
            return res.json({ status: 200, data: { signature: _signature, code: _claimCode }})
        }
        else {
            return res.json({ status: 200, data: _signature })
        }
    } catch(err) {
        console.log(err)
        return res.json({ status: 500, error: err.message })
    }

})

module.exports = router;