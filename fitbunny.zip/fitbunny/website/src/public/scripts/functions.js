//- Hiding the # from links
var links = document.getElementsByTagName("a");
Array.prototype.forEach.call(links, function(elem, index) {
    var elemAttr = elem.getAttribute("href");
    if(elemAttr && elemAttr.includes("#")) {
        elem.addEventListener("click", function(ev) {
        ev.preventDefault()
        document.getElementById(elemAttr.replace(/#/g, "")).scrollIntoView({
                behavior: "smooth",
                block: "start",
                inline: "nearest"
            })
        })
    }
})

//- General
function getUrlVars() {
    var vars = {}
    var parts = window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi, function(m,key,value) {
        vars[key] = value
    })

    return vars
}


/** NAVIGATION */
async function openNav() {
    $('.nav_content').css('display', 'flex')
    $('.mnav_control').html('<i class="ri-close-line"></i>')
    $('.mnav_control').attr('onclick', 'closeNav()')
}
async function closeNav() {
    if(window.innerWidth < 810) {
        $('.nav_content').css('display', 'none')
        $('.mnav_control').html('<i class="ri-menu-line"></i>')
        $('.mnav_control').attr('onclick', 'openNav()')
    }
}

// Define the open_question function globally so it can be accessed from the onclick attribute
window.open_question = function(questionId) {
    // Select the answer element related to the clicked question
    var $answer = $('.q_' + questionId + ' .answer');
    var $indicator = $('.q_' + questionId + ' .q_indicator i');

    // Check if the answer is currently visible
    if ($answer.is(':visible')) {
        // If the answer is visible, slide it up
        $answer.slideUp(500, function() {
            // Change the indicator arrow to 'down' after the animation completes
            $indicator.removeClass('ri-arrow-up-s-line').addClass('ri-arrow-down-s-line');
        });
    } else {
        // If the answer is not visible, slide it down
        $answer.slideDown(500, function() {
            // Change the indicator arrow to 'up' after the animation completes
            $indicator.removeClass('ri-arrow-down-s-line').addClass('ri-arrow-up-s-line');
        });
    }
};