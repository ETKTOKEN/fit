
/** Wallet Settings */
let _wallet = null
let _signer = null
let _provider = null

/** Contract Settings */
let _CONTRACT_ADDR = '0x71d1212DD9E310bDD69D893672dd62FACaC4B0Ce'
let _contract = null
let _iFace = null

/** Mint Setting */
let _publicEnabled = false
let _whitelistEnabled = false
let _claimEnabled = false

let _publicPrice = null
let _whitelistPrice = null

let _currentSupply = null
let _maxSupply = null

let _mintAmount = 1
let _mintLimit = 10

/** Wallet Login */
async function wallet_login() {
    if(window.ethereum) {
        await ethereum.request({ method: 'eth_requestAccounts' })
            .then( async _accounts => {

                _wallet = _accounts[0]
                _provider = new ethers.providers.Web3Provider(window.ethereum)
                _signer = _provider.getSigner()

                setupListeners()
                setupChain()

            }).catch(_err => {
                post_error(_err.message)
            })
    }
    else {
        post_error('Please install a wallet and try again')
    }
}

function setupListeners() {
    ethereum.on("chainChanged", () => { window.location.reload(); });

    ethereum.on("connect", (info) => { console.log(`Connected to network ${info}`) })

    ethereum.on("disconnect", (error) => {
        console.log(`Disconnected from network ${error}`)
        window.location.reload();
    })

    ethereum.on("_accountsChanged", (_accounts) => {
        if (_accounts.length > 0) { window.location.reload(); } 
        else { window.location.reload(); }
    })
}

async function setupChain() {
    _provider.getNetwork().then(async _res => {

        //- Testnet Setup
        if(_res.chainId != 137) {
            await ethereum.request({
                method: 'wallet_switchEthereumChain',
                params: [{ chainId: '0x89' }],
            }).then(() => { setupApp() })
            .catch(_err => {
                post_error('Please use Polygon Mainnet & try again')
            })
        }

        //- Mainnet Setup //TODO: work out what this actually needs to be
        // if(_res.chainId != 1) {
        //     await ethereum.request({
        //         method: 'wallet_switchEthereumChain',
        //         params: [{ chainId: '0x1' }],
        //     }).then(() => { setupApp() })
        //     .catch(_err => {
        //         post_error('Please use Ethereum Mainnet & try again')
        //     })
        // }

        else setupApp()
    })
}

/**  */
async function setupApp() {

    //- Changing mint display
    $('.mc_d_login').css('display', 'none')
    $('.mc_d_mint_success').css('display', 'none')
    $('.mc_d_loading').css('display', 'block')

    //- Connecting the the contract
    _contract = new ethers.Contract(_CONTRACT_ADDR, _abi, _signer)
    iface = new ethers.utils.Interface(_abi)

    //- Getting the contract settings
    _publicEnabled = await _contract.publicEnabled()
    _whitelistEnabled = await _contract.whitelistEnabled()
    _claimEnabled = await _contract.claimEnabled()

    console.log(`_publicEnabled: ${_publicEnabled}`)
    console.log(`_whitelistEnabled: ${_whitelistEnabled}`)
    console.log(`_claimEnabled: ${_claimEnabled}`)

    _currentSupply = await _contract.totalSupply()
    _maxSupply = await _contract.maxSupply()

    _publicPrice = await _contract.price()
    _whitelistPrice = await _contract.whitelistPrice()

    //- Setting the mint phase
    if(_claimEnabled) { setupClaim() }
    else if(_whitelistEnabled) { setupWhitelist() }
    else if(_publicEnabled) { setupPublic() }
    else { 
        $('.mc_d_loading').css('display', 'none')
        $('.mc_d_not_active').css('display', 'block')
        return;
    }

}

/** Display Setup */
async function setupClaim() {
    
    let _canMint = false
    try {
        let _req = await isWhitelisted('free')
        if(_req.status === 200) _canMint = _req.data
        else {
            post_error('An error occurred while fetching the whitelist status')
            return;
        }
    } catch(err) {
        post_error('An error occurred while fetching the whitelist status')
        return;
    }

    if(!_canMint) {
        post_error(`You are not eligible for a free claim.`)
        $('.mc_d_loading').css('display', 'none')
        $('.mc_d_not_active').css('display', 'block')
        return;
    }

    //- Setting the information on the front end
    $('.mint_phase').html('Free Claim Phase')
    $('._mint_price').html(`Free Claim`)
    $('._current_mint_amount').html(Number(_currentSupply).toLocaleString('en-US'))
    $('._mint_phase_limit').html(Number(_maxSupply).toLocaleString('en-US'))
    $('#_mint_s_btn').attr('onclick', 'claim_token()')

    //- Changing the display
    $('.mc_d_loading').css('display', 'none')
    $('.mc_d_mint_settings').css('display', 'block')

    _mintLimit = 1

}

async function setupWhitelist() {

    let _canMint = false
    try {
        let _req = await isWhitelisted('whitelist')
        if(_req.status === 200) _canMint = _req.data
        else {
            post_error('An error occurred while fetching the whitelist status')
            return;
        }
    } catch(err) {
        post_error('An error occurred while fetching the whitelist status')
        return;
    }

    if(!_canMint) {
        post_error(`You are not eligible for the Whitelist.`)
        $('.mc_d_loading').css('display', 'none')
        $('.mc_d_not_active').css('display', 'block')
        return;
    }

    //- Setting the information on the front end
    $('.mint_phase').html('Whitelist Phase')
    $('._mint_price').html(ethers.utils.formatEther(_whitelistPrice))
    $('._current_mint_amount').html(Number(_currentSupply).toLocaleString('en-US'))
    $('._mint_phase_limit').html(Number(_maxSupply).toLocaleString('en-US'))
    $('#_mint_s_btn').attr('onclick', 'whitelist_mint()')

    //- Changing the display
    $('.mc_d_loading').css('display', 'none')
    $('.mc_d_mint_settings').css('display', 'block')

    _mintLimit = 1

}

function setupPublic() {

    //- Setting the information on the front end
    $('.mint_phase').html('Public Phase')
    $('._mint_price').html(ethers.utils.formatEther(_publicPrice))
    $('._current_mint_amount').html(Number(_currentSupply).toLocaleString('en-US'))
    $('._mint_phase_limit').html(Number(_maxSupply).toLocaleString('en-US'))
    $('#_mint_s_btn').attr('onclick', 'public_mint()')

    //- Changing the display
    $('.mc_d_loading').css('display', 'none')
    $('.mc_d_mint_settings').css('display', 'block')

    _mintLimit = 10

}

/** Mint Functions */
async function claim_token() {
    post_error('')

    if($('#_mint_s_btn').hasClass('disabled')) {
        console.log(`disabled_btn`)
        return;
    }

    //- Disabling the mint button
    $('#_mint_s_btn').addClass('disabled')

    //- Getting the mint signature
    let _signature = null
    try { 
        let _sigReq = await getMintSignature('free', _claimEnabled)  
        if(_sigReq.status === 200) _signature = _sigReq.data
        else {
            post_error('An error occurred while fetching the mint signature')
            $('#_mint_s_btn').removeClass('disabled')
            return;
        }
    } catch(err) {
        post_error('An error occurred while fetching the mint signature')
        $('#_mint_s_btn').removeClass('disabled')
        return;
    }

    //- Getting the gas estimate
    let _gasEstimate = null
    try {
        _gasEstimate = await _contract.estimateGas.freeClaim(_wallet, _mintAmount, _signature.code, _signature.signature)
    }
    catch (err) { 
            
        console.log(err)
    
        //- Parsing the error:
        let _errName = 'error'
        if(err.toString().includes('(error=')) {
            let _errorParse = err.toString().split('(error=')[1].split(', code=')[0]
            let _reason = _errorParse.split('"data":"')[1].split('","')[0]
            console.log(`Err Reason: ${_reason}`)

            try { _errName = _iface.getError(_reason).name }
            catch(_err) { _errName = 'error' }
            console.log(`Err: ${_errName}`)
        }

        post_error('An error has occurred estimating gas for the transaction. Please try again later or contact a member of the team for more')
        $('#_mint_s_btn').removeClass('disabled')
        return
    }

    //- Submitting to the blockchain
    if(_gasEstimate) {
        let _options = {
            gasLimit: Math.ceil(_gasEstimate * 1.5)
        }

        try {
            _contract.freeClaim(_wallet, _mintAmount, _signature.code, _signature.signature, _options)
                .then(async _res => {

                    //- Setting the Tx Link
                    let _txLink = `https://polygonscan.com/tx/${_res.hash}`
                    $('.tx_link').attr('href', _txLink)
                    
                    //- Updating the display
                    $('.mc_d_mint_settings').css('display', 'none')
                    $('.mc_d_mint_processing').css('display', 'block')

                    _res.wait(1).then(async () => {
                        $('.mc_d_mint_processing').css('display', 'none')
                        $('.mc_d_mint_success').css('display', 'block')

                        $('#_mint_s_btn').removeClass('disabled')
                    })

                }).catch(_err => {
                    console.log(_err)
                    
                    $('#_mint_s_btn').removeClass('disabled')
        
                    //- Parsing the error:
                    let _errName = 'error'
                    if(_err.toString().includes('(error=')) {
                        let _errorParse = _err.toString().split('(error=')[1].split(', code=')[0]
                        let _reason = _errorParse.split('"data":"')[1].split('","')[0]
                        console.log(`Err Reason: ${_reason}`)

                        try { _errName = _iface.getError(_reason).name }
                        catch(_error) { _errName = 'error' }
                        console.log(`Err: ${_errName}`)
                    }

                    post_error('An error has occurred submitting your transaction. Please try again later or contact a member of the team for more')
                    $('#_mint_s_btn').removeClass('disabled')
                    return
                })
        } catch (err) { 
            
            console.log(err)
        
            //- Parsing the error:
            let _errName = 'error'
            if(err.toString().includes('(error=')) {
                let _errorParse = err.toString().split('(error=')[1].split(', code=')[0]
                let _reason = _errorParse.split('"data":"')[1].split('","')[0]
                console.log(`Err Reason: ${_reason}`)

                try { _errName = _iface.getError(_reason).name }
                catch(_err) { _errName = 'error' }
                console.log(`Err: ${_errName}`)
            }

            post_error('An error has occurred while submitting your transaction. Please try again later or contact a member of the team for more')
            $('#_mint_s_btn').removeClass('disabled')
            return
        }
    } 

    else { 
        post_error('An error has occurred while submitting your transaction. Please try again later or contact a member of the team for more')
        $('#_mint_s_btn').removeClass('disabled')
    }


}

async function whitelist_mint() { 
    post_error('')

    if($('#_mint_s_btn').hasClass('disabled')) {
        console.log(`disabled_btn`)
        return;
    }

    //- Disabling the mint button
    $('#_mint_s_btn').addClass('disabled')

    //- Getting the mint signature
    let _signature = null
    try { 
        let _sigReq = await getMintSignature('whitelist', _whitelistEnabled)  
        if(_sigReq.status === 200) _signature = _sigReq.data
        else {
            post_error('An error occurred while fetching the mint signature')
            $('#_mint_s_btn').removeClass('disabled')
            return;
        }
    } catch(err) {
        post_error('An error occurred while fetching the mint signature')
        $('#_mint_s_btn').removeClass('disabled')
        return;
    }

    //- Final Cost
    let _finalCost = _whitelistPrice * _mintAmount

    //- Getting the gas estimate
    let _gasEstimate = null
    try {
        _gasEstimate = await _contract.estimateGas.whitelistMint(_wallet, _mintAmount, _signature.code, _signature.signature, { value: _finalCost.toString() })
    }
    catch (err) { 
            
        console.log(err)
    
        //- Parsing the error:
        let _errName = 'error'
        if(err.toString().includes('(error=')) {
            let _errorParse = err.toString().split('(error=')[1].split(', code=')[0]
            let _reason = _errorParse.split('"data":"')[1].split('","')[0]
            console.log(`Err Reason: ${_reason}`)

            try { _errName = _iface.getError(_reason).name }
            catch(_err) { _errName = 'error' }
            console.log(`Err: ${_errName}`)
        }

        post_error('An error has occurred estimating gas for the transaction. Please try again later or contact a member of the team for more. Please check the amount you are trying to mint and try again.')
        $('#_mint_s_btn').removeClass('disabled')
        return
    }

    //- Submitting to the blockchain
    if(_gasEstimate) {
        let _options = {
            value: _finalCost.toString(),
            gasLimit: Math.ceil(_gasEstimate * 1.5)
        }

        try {
            _contract.whitelistMint(_wallet, _mintAmount, _signature.code, _signature.signature, _options)
                .then(async _res => {

                    //- Setting the Tx Link
                    let _txLink = `https://polygonscan.com/tx/${_res.hash}`
                    $('.tx_link').attr('href', _txLink)
                    
                    //- Updating the display
                    $('.mc_d_mint_settings').css('display', 'none')
                    $('.mc_d_mint_processing').css('display', 'block')

                    _res.wait(1).then(async () => {
                        $('.mc_d_mint_processing').css('display', 'none')
                        $('.mc_d_mint_success').css('display', 'block')

                        $('#_mint_s_btn').removeClass('disabled')
                    })

                }).catch(_err => {
                    console.log(_err)
                    
                    $('#_mint_s_btn').removeClass('disabled')
        
                    //- Parsing the error:
                    let _errName = 'error'
                    if(_err.toString().includes('(error=')) {
                        let _errorParse = _err.toString().split('(error=')[1].split(', code=')[0]
                        let _reason = _errorParse.split('"data":"')[1].split('","')[0]
                        console.log(`Err Reason: ${_reason}`)

                        try { _errName = _iface.getError(_reason).name }
                        catch(_error) { _errName = 'error' }
                        console.log(`Err: ${_errName}`)
                    }

                    post_error('An error has occurred submitting your transaction. Please try again later or contact a member of the team for more. Please check the amount you are trying to mint and try again.')
                    $('#_mint_s_btn').removeClass('disabled')
                    return
                })
        } catch (err) { 
            
            console.log(err)
        
            //- Parsing the error:
            let _errName = 'error'
            if(err.toString().includes('(error=')) {
                let _errorParse = err.toString().split('(error=')[1].split(', code=')[0]
                let _reason = _errorParse.split('"data":"')[1].split('","')[0]
                console.log(`Err Reason: ${_reason}`)

                try { _errName = _iface.getError(_reason).name }
                catch(_err) { _errName = 'error' }
                console.log(`Err: ${_errName}`)
            }

            post_error('An error has occurred while submitting your transaction. Please try again later or contact a member of the team for more')
            $('#_mint_s_btn').removeClass('disabled')
            return
        }
    } 

    else { 
        post_error('An error has occurred while submitting your transaction. Please try again later or contact a member of the team for more')
        $('#_mint_s_btn').removeClass('disabled')
    }


}

async function public_mint() { 
    post_error('')

    if($('#_mint_s_btn').hasClass('disabled')) {
        console.log(`disabled_btn`)
        return;
    }

    //- Disabling the mint button
    $('#_mint_s_btn').addClass('disabled')

    //- Getting the mint signature
    let _signature = null
    try { 
        let _sigReq = await getMintSignature('public', _publicEnabled)  
        if(_sigReq.status === 200) _signature = _sigReq.data
        else {
            post_error('An error occurred while fetching the mint signature')
            $('#_mint_s_btn').removeClass('disabled')
            return;
        }
    } catch(err) {
        post_error('An error occurred while fetching the mint signature')
        $('#_mint_s_btn').removeClass('disabled')
        return;
    }

    //- Final Cost
    let _finalCost = _whitelistPrice * _mintAmount

    //- Getting the gas estimate
    let _gasEstimate = null
    try {
        _gasEstimate = await _contract.estimateGas.publicMint(_wallet, _mintAmount, _signature, { value: _finalCost.toString() })
    }
    catch (err) { 
            
        console.log(err)
    
        //- Parsing the error:
        let _errName = 'error'
        if(err.toString().includes('(error=')) {
            let _errorParse = err.toString().split('(error=')[1].split(', code=')[0]
            let _reason = _errorParse.split('"data":"')[1].split('","')[0]
            console.log(`Err Reason: ${_reason}`)

            try { _errName = _iface.getError(_reason).name }
            catch(_err) { _errName = 'error' }
            console.log(`Err: ${_errName}`)
        }

        post_error('An error has occurred estimating gas for the transaction. Please try again later or contact a member of the team for more. Please check the amount you are trying to mint and try again.')
        $('#_mint_s_btn').removeClass('disabled')
        return
    }

    //- Submitting to the blockchain
    if(_gasEstimate) {
        let _options = {
            value: _finalCost.toString(),
            gasLimit: Math.ceil(_gasEstimate * 1.5)
        }

        try {
            _contract.publicMint(_wallet, _mintAmount, _signature, _options)
                .then(async _res => {

                    //- Setting the Tx Link
                    let _txLink = `https://polygonscan.com/tx/${_res.hash}`
                    $('.tx_link').attr('href', _txLink)
                    
                    //- Updating the display
                    $('.mc_d_mint_settings').css('display', 'none')
                    $('.mc_d_mint_processing').css('display', 'block')

                    _res.wait(1).then(async () => {
                        $('.mc_d_mint_processing').css('display', 'none')
                        $('.mc_d_mint_success').css('display', 'block')

                        $('#_mint_s_btn').removeClass('disabled')
                    })

                }).catch(_err => {
                    console.log(_err)
                    
                    $('#_mint_s_btn').removeClass('disabled')
        
                    //- Parsing the error:
                    let _errName = 'error'
                    if(_err.toString().includes('(error=')) {
                        let _errorParse = _err.toString().split('(error=')[1].split(', code=')[0]
                        let _reason = _errorParse.split('"data":"')[1].split('","')[0]
                        console.log(`Err Reason: ${_reason}`)

                        try { _errName = _iface.getError(_reason).name }
                        catch(_error) { _errName = 'error' }
                        console.log(`Err: ${_errName}`)
                    }

                    post_error('An error has occurred submitting your transaction. Please try again later or contact a member of the team for more. Please check the amount you are trying to mint and try again.')
                    $('#_mint_s_btn').removeClass('disabled')
                    return
                })
        } catch (err) { 
            
            console.log(err)
        
            //- Parsing the error:
            let _errName = 'error'
            if(err.toString().includes('(error=')) {
                let _errorParse = err.toString().split('(error=')[1].split(', code=')[0]
                let _reason = _errorParse.split('"data":"')[1].split('","')[0]
                console.log(`Err Reason: ${_reason}`)

                try { _errName = _iface.getError(_reason).name }
                catch(_err) { _errName = 'error' }
                console.log(`Err: ${_errName}`)
            }

            post_error('An error has occurred while submitting your transaction. Please try again later or contact a member of the team for more')
            $('#_mint_s_btn').removeClass('disabled')
            return
        }
    } 

    else { 
        post_error('An error has occurred while submitting your transaction. Please try again later or contact a member of the team for more')
        $('#_mint_s_btn').removeClass('disabled')
    }


}

/** Utility */
async function post_error(_msg) {
    let _err = $('.err_msg')
    _err.html(_msg)
}

function addMintAmount () {
    _mintAmount++ 
    _mintAmount = _mintAmount > _mintLimit ? _mintLimit : _mintAmount
    $('._mint_amount').html(_mintAmount)
}

function remMintAmount () {
    _mintAmount-- 
    _mintAmount = _mintAmount < 1 ? 1 : _mintAmount
    $('._mint_amount').html(_mintAmount)
}

function getMintSignature (_claimType, _mintStatus) {
    return new Promise(async (resolve, reject) => {
        $.ajax({
            type: 'POST',
            url: '/api/signature',
            dataType: 'json',
            data: { wallet: _wallet, amount: _mintAmount, mint_enabled: _mintStatus, claim_type: _claimType },
            success: (_data) => { 
                return resolve(_data)
            },
            error: (_err) => { 
                console.log(_err)
                reject({ status: 500 }) 
            }
        })
    })
}

function isWhitelisted(_claimType) {
    return new Promise(async (resolve, reject) => {
        $.ajax({
            type: 'POST',
            url: '/api/is-whitelist',
            dataType: 'json',
            data: { wallet: _wallet, claim_type: _claimType },
            success: (_data) => { 
                return resolve(_data)
            },
            error: (_err) => { 
                console.log(_err)
                reject({ status: 500 }) 
            }
        })
    })
}