const mongoose = require('mongoose');

/** SCHEMA
 * @param : {String} : The ID of the guild
 */
const model = new mongoose.Schema({
    guild_id : { type: String, required: true }, 
})

const Schema = module.exports = mongoose.model('schema', model)