//- ENV variables
require('dotenv').config();

//- The express server framework setup
const express = require('express');
const app = express();
const PORT = process.env.PORT || 5000
const IP = process.env.IP || '0.0.0.0'

//- Database
// const db = require('./addons/database/database')
// db.then(() => { console.log(`Connected to the MongoDB`) }).catch(_err => console.log(_err))

//- Body Parser
var bodyParser = require('body-parser')
app.use(bodyParser.json()); // for parsing application/json
app.use(bodyParser.urlencoded({ extended: true })); // for parsing application/x-www-form-urlencoded

//- Starting the app
app.listen(PORT, IP, () => { console.log(`App started on ${IP}:${PORT}`); });

//- View Engine
const path = require('path')

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'))
app.use(express.static(path.join(__dirname, 'public')))

//- Routing
app.use('/', require('./routes/index'))
app.use('/mint', require('./routes/mint'))
app.use('/api/signature', require('./routes/api/signature'))
app.use('/api/is-whitelist', require('./routes/api/is-whitelist'))
